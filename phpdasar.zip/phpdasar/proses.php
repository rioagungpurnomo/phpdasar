<?php

$conn = mysqli_connect("localhost", "root", "", "phpdasar");
$total_produk = mysqli_query($conn, "SELECT * FROM produk");
$total_produk_terjual = mysqli_query($conn, "SELECT * FROM produk_terjual");
$produk = mysqli_num_rows($total_produk);
$produk_terjual = mysqli_num_rows($total_produk_terjual);


function query($query)
{
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function tambah($data)
{
    global $conn;

    $judul = htmlspecialchars($data["judul"]);
    $deskripsi = htmlspecialchars($data["deskripsi"]);
    $waktu = time();

    if ($data == true) {

        $query = "INSERT INTO produk VALUES('', '$judul', '$deskripsi', '$waktu')";

        mysqli_query($conn, $query);

        return mysqli_affected_rows($conn);
    } else {
        echo 'Gagal Menambahkan Produk';
    }
}


function edit($data)
{
    global $conn;

    $id = $data["id"];
    $judul = htmlspecialchars($data["judul"]);
    $deskripsi = htmlspecialchars($data["deskripsi"]);

    $query = "UPDATE produk SET judul = '$judul', deskripsi = '$deskripsi' WHERE id = $id";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

function hapus($data)
{
    global $conn;

    mysqli_query($conn, "DELETE FROM produk WHERE id = '$data'");

    return mysqli_affected_rows($conn);
}
