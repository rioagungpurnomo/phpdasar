<?php

require 'proses.php';

$i = 1;
$list_produk = query("SELECT * FROM produk");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>

    <style>
        table,
        th,
        td {
            border: 1px solid black;
        }
    </style>
</head>

<body>

    <h1>Home</h1>

    <a href="tambah.php">+ Tambah Produk Baru</a>

    <br>
    <br>

    <table>
        <tr>
            <th>#</th>
            <th>Judul</th>
            <th>Deskripsi</th>
            <th>Waktu Upload</th>
            <th>Edit</th>
            <th>Hapus</th>
        </tr>
        <?php foreach ($list_produk as $p) : ?>
            <tr>
                <td><?= $i++; ?></td>
                <td><?= $p['judul']; ?></td>
                <td><?= $p['deskripsi']; ?></td>
                <td><?= date("d- M - Y", $p['waktu']); ?></td>
                <td><a href="edit.php?id=<?= $p['id']; ?>" type="button">Edit</a></td>
                <td><a href="hapus.php?id=<?= $p['id']; ?>" type="button">Hapus</a></td>
            </tr>
        <?php endforeach; ?>
    </table>


</body>

</html>