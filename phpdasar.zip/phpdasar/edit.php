<?php

require 'proses.php';

$id = $_GET['id'];

$ep = query("SELECT * FROM produk WHERE id = '$id'")[0];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["edit"])) {
        if (edit($_POST) > 0) {
            echo "Produk berhasil perbarui!";
        } else {
            echo mysqli_error($conn);
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <style>
        label,
        button {
            display: block;
        }

        input {
            width: 300px;
            margin-bottom: 15px;
            height: 20px;
        }

        button {
            width: 310px;
            height: 30px;
            background-color: green;
            color: white;
        }
    </style>
</head>

<body>

    <h1>Edit Produk</h1>

    <form action="" method="post">
        <input type="hidden" name="id" value="<?= $id; ?>" required>
        <label for="judul">Judul</label>
        <input type="text" name="judul" id="judul" value="<?= $ep['judul']; ?>" required>
        <label for="deskripsi">Deskripsi</label>
        <input type="text" name="deskripsi" id="deskripsi" value="<?= $ep['deskripsi']; ?>" required>
        <button type="submit" name="edit">Edit</button>
    </form>

</body>

</html>