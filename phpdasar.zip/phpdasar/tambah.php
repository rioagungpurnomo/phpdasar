<?php

require 'proses.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["tambah"])) {
        if (tambah($_POST) > 0) {
            echo "Produk baru berhasil ditambahkan!";
        } else {
            echo mysqli_error($conn);
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <style>
        label,
        button {
            display: block;
        }

        input {
            width: 300px;
            margin-bottom: 15px;
            height: 20px;
        }

        button {
            width: 310px;
            height: 30px;
            background-color: green;
            color: white;
        }
    </style>
</head>

<body>

    <h1>Tambah Produk</h1>

    <form action="" method="post">
        <label for="judul">Judul</label>
        <input type="text" name="judul" id="judul" placeholder="Judul" required>
        <label for="deskripsi">Deskripsi</label>
        <input type="text" name="deskripsi" id="deskripsi" placeholder="Deskripsi" required>
        <button type="submit" name="tambah">Tambah</button>
    </form>

</body>

</html>